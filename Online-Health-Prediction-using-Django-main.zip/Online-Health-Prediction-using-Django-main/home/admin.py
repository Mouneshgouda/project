from django.contrib import admin
from .models import ObesityData

# Register your models here.
admin.site.register(ObesityData)